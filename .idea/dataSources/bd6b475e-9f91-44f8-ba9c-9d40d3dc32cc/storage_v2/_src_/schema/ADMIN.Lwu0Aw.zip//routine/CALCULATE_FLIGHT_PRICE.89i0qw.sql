create function calculate_flight_price
(seat number)
return float
IS
v_flight_id number;
v_distance_in_km number;
v_class varchar2(255);
factor float;
begin
    BEGIN

    select flight_id
    into v_flight_id
    from seats_in_plane
    where seat_id = seat;

    select distance_in_km 
    into v_distance_in_km
    from flights
    where flight_id = v_flight_id;

    select seat_class
    into v_class
    from seats_in_plane
    where seat_id = seat;

    IF v_class = 'First' then
    factor := 2.5;
    ELSIF v_class = 'Business' then
    factor := 1.5;
    ELSE factor := 1;
    END IF;

    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    dbms_output.put_line('no data found');
    v_distance_in_km := -1;
    factor := -1;
    rollback;
    END;



RETURN floor(factor * v_distance_in_km / 4);
end;
/

