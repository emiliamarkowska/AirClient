create PROCEDURE populate_flight
(nflights in number)
is
from_id number;
to_id number;
departure timestamp;
v_time timestamp;
arrival timestamp;
difference_in_hours number;
difference_in_minutes number;
distance_in_km number;
counter number := 1;
begin

while counter < nflights 
loop

SELECT airport_id 
into from_id
FROM   
(SELECT airport_id FROM airports  
ORDER BY dbms_random.value)  
WHERE rownum = 1 ;

to_id := from_id;

while to_id = from_id
loop
    SELECT airport_id 
    into to_id
    FROM   
    (SELECT airport_id FROM airports  
    ORDER BY dbms_random.value)  
    WHERE rownum = 1 ;
end loop;

v_time  := TO_TIMESTAMP('2020/01/01 00:00', 'YYYY/MM/DD HH24:MI');

SELECT v_time + 
         dbms_random.value(0, 100) 
  INTO departure
  FROM dual;

SELECT departure + dbms_random.value(2,6)/24
    INTO arrival
    FROM dual;


difference_in_hours := extract (hour from (arrival - departure));


difference_in_minutes := extract(minute from (arrival - departure));

distance_in_km :=   FLOOR((difference_in_hours + difference_in_minutes / 60)* 800);

dbms_output.put_line( 'INTO FLIGHTS (from_id, to_id, departure_time, arrival_time, distance_in_km) VALUES (' ||
'''' || from_id || ''' , ' || 
'''' || to_id || ''', ' || 

 'TO_TIMESTAMP(' ||
'''' || TO_CHAR(departure,'YYYY/MM/DD HH24:MI') || ''',''YYYY/MM/DD HH24:MI'' ),' ||
 'TO_TIMESTAMP(' ||
'''' || TO_CHAR(arrival,'YYYY/MM/DD HH24:MI') ||  ''',''YYYY/MM/DD HH24:MI'' ),' || 
'''' || distance_in_km || ''')');  


 -- DBMS_OUTPUT.PUT_LINE(TO_CHAR(DEPARTURE, 'HH24:MI'));

counter := counter + 1;

end loop;
end;
/

