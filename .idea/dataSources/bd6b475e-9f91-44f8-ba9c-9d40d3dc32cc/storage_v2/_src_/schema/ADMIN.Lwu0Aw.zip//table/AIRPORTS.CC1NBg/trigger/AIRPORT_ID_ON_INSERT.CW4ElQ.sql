create trigger AIRPORT_ID_ON_INSERT
  before insert
  on AIRPORTS
  for each row
BEGIN
  SELECT airport_sequence.nextval
  INTO :new.airport_id
  FROM dual;
END;
/

