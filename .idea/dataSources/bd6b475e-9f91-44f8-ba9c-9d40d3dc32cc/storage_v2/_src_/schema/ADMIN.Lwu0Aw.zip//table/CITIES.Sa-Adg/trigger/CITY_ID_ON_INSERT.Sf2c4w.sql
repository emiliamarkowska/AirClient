create trigger CITY_ID_ON_INSERT
  before insert
  on CITIES
  for each row
BEGIN
  SELECT city_sequence.nextval
  INTO :new.city_ID
  FROM dual;
END;
/

