create trigger COUNTRY_ID_ON_INSERT
  before insert
  on COUNTRIES
  for each row
BEGIN
  SELECT country_sequence.nextval
  INTO :new.COUNTRY_ID
  FROM dual;
END;
/

