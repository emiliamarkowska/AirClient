create trigger EVENTS_LOG_ON_INSERT
  before insert
  on EVENTS_LOG
  for each row
BEGIN
  SELECT EVENT_LOGS_SEQUENCE.nextval
  INTO :new.event_id
  FROM dual;
END;
/

