create trigger FLIGHT_ID_ON_INSERT
  before insert
  on FLIGHTS
  for each row
BEGIN
  SELECT flight_sequence.nextval
  INTO :new.flight_id
  FROM dual;
END;
/

