create trigger SEATS_ID_ON_INSERT
  before insert
  on SEATS_IN_PLANE
  for each row
BEGIN
  SELECT SEATS_IN_PLANE_SEQUENCE.nextval
  INTO :new.seat_id
  FROM dual;
END;
/

