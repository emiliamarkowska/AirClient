create trigger TICKETS_ON_INSERT
  before insert
  on TICKETS
  for each row
BEGIN
  SELECT TICKETS_SEQUENCE.nextval
  INTO :new.ticket_id
  FROM dual;
END;
/

