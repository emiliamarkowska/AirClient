create trigger USER_ID_ON_INSERT
  before insert
  on USERS
  for each row
BEGIN
  SELECT user_sequence.nextval
  INTO :new.user_id
  FROM dual;
END;
/

